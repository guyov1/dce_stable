===================
 API documentation
===================

The MarsBaR code is reasonably well documented; we export this
documentation as web pages using Guillaume Flandin's excellent
`m2html`_. The API documents are in `the doc-stable/latest
<../doc-stable/latest>`_ directory of the website, for the stable version,
and `the doc-devel/latest <../doc-devel/latest>`_ for the development version.

.. include:: ../links_names.txt
