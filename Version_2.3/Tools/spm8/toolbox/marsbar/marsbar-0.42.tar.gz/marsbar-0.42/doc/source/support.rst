.. _support:

Support
~~~~~~~

We hope it is clear how to use MarsBaR, but please let us know if you
have problems. In particular, we would be very glad to hear of any
bugs or inconsistencies.

There is a mailing list for MarsBaR; list archives and instructions
for posting are available via the `MarsBaR users mailing list`_ page.
There is also a `MarsBaR mailing list archive`_. `Gmane`_ also
provides a nice interface to `recent MarsBaR emails`_.

.. include:: links_names.txt
