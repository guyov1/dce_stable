function tf = has_space(obj)
% has_space method - returns true if object has a native space
%
% $Id$

tf = 1; % default is true