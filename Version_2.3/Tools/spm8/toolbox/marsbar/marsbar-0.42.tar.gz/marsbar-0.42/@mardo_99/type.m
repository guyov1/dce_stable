function str = type(o)
% returns SPM version string corresponding to design type
%
% $Id$
 
str = 'SPM99';