function str = type(o)
% returns SPM version string corresponding to design type
% 
% $Id: type.m 76 2003-12-25 08:19:13Z matthewbrett $ 
  
str = 'SPM5';