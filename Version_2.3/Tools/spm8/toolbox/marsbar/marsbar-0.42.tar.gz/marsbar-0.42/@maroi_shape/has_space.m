function tf = has_space(obj)
% has_space method - returns true if object has a native space
%
% $Id$

tf = 0; % not true of shape object