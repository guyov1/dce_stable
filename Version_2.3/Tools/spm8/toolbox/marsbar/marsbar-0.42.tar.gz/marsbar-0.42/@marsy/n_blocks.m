function n = n_blocks(Y)
% method returns number of subjects/sessions in data
%
% $Id$ 
  
n = length(block_rows(Y));