function tf = has_images(o)
% returns 1 if design contains images, NaN if not known
% 
% $Id$

tf = NaN;