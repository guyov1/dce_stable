function tf = isempty(o)
% overloaded isempty method for mardo object
% 
% $Id$
  
tf = isempty(o.des_struct);
